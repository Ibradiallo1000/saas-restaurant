"use client"

import * as React from "react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { RoleSwitch } from "@/components/layout/RoleSwitch"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { ThemeToggle } from "@/components/ui/theme-toggle"
import { usePlatform } from "@/contexts/platform-context"
import { useUser } from "@/firebase"

export function Header() {
  const { settings } = usePlatform()
  const { user } = useUser()
  const userInitials = getInitials(user?.email)

  return (
    <header className="sticky top-0 z-20 flex min-h-16 items-center justify-between border-b bg-background/80 px-4 backdrop-blur md:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <SidebarTrigger className="h-10 w-10 rounded-md focus-visible:ring-2 focus-visible:ring-primary" />
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-foreground">{settings.name}</div>
          <div className="hidden text-xs text-muted-foreground sm:block">Console SaaS</div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <RoleSwitch />
        <ThemeToggle />
        <Avatar className="h-10 w-10 border">
          <AvatarImage src={user?.photoURL ?? undefined} alt={user?.email ?? "Utilisateur"} />
          <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
            {userInitials}
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}

function getInitials(email?: string | null) {
  if (!email) return "U"
  const [name] = email.split("@")
  const parts = name.split(/[._-]/).filter(Boolean)

  if (parts.length >= 2) {
    return `${parts[0][0]}${parts[1][0]}`.toUpperCase()
  }

  return name.slice(0, 2).toUpperCase()
}
