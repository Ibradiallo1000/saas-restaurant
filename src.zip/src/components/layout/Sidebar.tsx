"use client"

import * as React from "react"
import {
  ChefHat,
  LayoutDashboard,
  LogOut,
  Monitor,
  Sparkles,
  Store,
  Users,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { signOut } from "firebase/auth"

import { Button } from "@/components/ui/button"
import {
  Sidebar as SidebarPrimitive,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from "@/components/ui/sidebar"
import { usePlatform } from "@/contexts/platform-context"
import { useAuth } from "@/firebase"
import { useCurrentUser } from "@/hooks/use-current-user"
import { ROLES } from "@/lib/constants"
import { cn } from "@/lib/utils"

type NavItem = {
  name: string
  href: string
  icon: React.ComponentType<{ className?: string }>
}

export function Sidebar() {
  const pathname = usePathname()
  const auth = useAuth()
  const { settings } = usePlatform()
  const { firebaseUser: user, activeRole, isSuperAdmin, restaurantId } = useCurrentUser()
  const { setOpenMobile } = useSidebar()

  const restaurantRole = activeRole ?? ROLES.SERVER
  const hasRestaurantAccess = Boolean(restaurantId && activeRole)

  const businessNav = React.useMemo<NavItem[]>(() => {
    if (!hasRestaurantAccess) return []

    if (restaurantRole === ROLES.OWNER || isSuperAdmin) {
      return [
        { name: "Analytics", href: "/owner", icon: LayoutDashboard },
        { name: "Manager", href: "/manager", icon: Store },
        { name: "Caisse", href: "/pos", icon: Monitor },
        { name: "Cuisine", href: "/kitchen", icon: ChefHat },
      ]
    }

    if (restaurantRole === ROLES.MANAGER) {
      return [
        { name: "Manager", href: "/manager", icon: Store },
        { name: "Caisse", href: "/pos", icon: Monitor },
        { name: "Cuisine", href: "/kitchen", icon: ChefHat },
      ]
    }

    if (restaurantRole === ROLES.CASHIER) {
      return [{ name: "Caisse POS", href: "/pos", icon: Monitor }]
    }

    if (restaurantRole === ROLES.KITCHEN) {
      return [{ name: "Cuisine", href: "/kitchen", icon: ChefHat }]
    }

    return []
  }, [hasRestaurantAccess, restaurantRole, isSuperAdmin])

  const navItems = businessNav
  const sectionLabel = `Espace ${restaurantRole}`

  return (
    <SidebarPrimitive
      variant="sidebar"
      collapsible="icon"
      className={cn(
        "border-r border-zinc-800",
        "[&_[data-sidebar=sidebar]]:bg-zinc-900",
        "[&_[data-sidebar=sidebar]]:text-white/80",
        "[&_[data-sidebar=sidebar]]:shadow-xl"
      )}
    >
      <SidebarHeader className="p-3">
        <div className="flex min-h-10 items-center gap-3 rounded-md px-2">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md bg-[hsl(var(--primary))] text-white shadow-sm">
            {settings.logoUrl ? (
              <img src={settings.logoUrl} alt={settings.name} className="h-full w-full object-cover" />
            ) : (
              <Sparkles className="h-5 w-5" />
            )}
          </div>
          <div className="min-w-0 group-data-[collapsible=icon]:hidden">
            <div className="truncate text-sm font-semibold text-white">{settings.name}</div>
            <div className="text-[10px] font-semibold uppercase tracking-widest text-white/45">
              SaaS Console
            </div>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-1">
        <SidebarGroup>
          <SidebarGroupLabel className="px-3 text-[10px] font-semibold uppercase tracking-widest text-white/40">
            {sectionLabel}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="gap-1">
              {navItems.map((item) => {
                const active = isActivePath(pathname, item.href)

                return (
                  <SidebarMenuItem key={item.name}>
                    <SidebarMenuButton
                      asChild
                      isActive={active}
                      tooltip={item.name}
                      className={cn(
                        "min-h-10 rounded-md text-white/75 transition-all duration-200 hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary))]",
                        active &&
                          "!bg-[hsl(var(--primary))] !font-medium !text-white hover:!bg-[hsl(var(--primary))] hover:!text-white [&>svg]:!text-white"
                      )}
                    >
                      <Link href={item.href} onClick={() => setOpenMobile(false)}>
                        <item.icon className="h-5 w-5" />
                        <span>{item.name}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-3">
        {user ? (
          <div className="flex min-h-10 items-center gap-3 rounded-md bg-white/5 p-2 text-white/80 group-data-[collapsible=icon]:justify-center">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-white">
              <Users className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden">
              <div className="truncate text-xs font-medium text-white">{user.email?.split("@")[0]}</div>
              <div className="truncate text-[10px] font-semibold uppercase text-white/40">
                {isSuperAdmin ? ROLES.SUPER_ADMIN : restaurantRole}
              </div>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-white/60 hover:bg-white/10 hover:text-white group-data-[collapsible=icon]:hidden"
              onClick={() => signOut(auth)}
            >
              <LogOut className="h-4 w-4" />
              <span className="sr-only">Se déconnecter</span>
            </Button>
          </div>
        ) : null}
      </SidebarFooter>
      <SidebarRail />
    </SidebarPrimitive>
  )
}

function isActivePath(pathname: string, href: string) {
  if (href === "/") return pathname === href
  return pathname === href || pathname.startsWith(`${href}/`)
}
