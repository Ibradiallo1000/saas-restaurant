"use client"

import * as React from "react"
import { doc } from "firebase/firestore"

import { useDoc, useFirestore, useMemoFirebase, useUser } from "@/firebase"
import { COLLECTION_NAMES } from "@/lib/constants"

type StaffAccess = {
  user: ReturnType<typeof useUser>["user"]
  isLoading: boolean
  restaurantId: string | null
  role: string | null
  active: boolean
  isAllowed: boolean
}

export function useRestaurantAccess(allowedRoles: string[]): StaffAccess {
  const db = useFirestore()
  const { user, isUserLoading } = useUser()
  const allowedKey = allowedRoles.join("|")

  const userProfileRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, COLLECTION_NAMES.USERS, user.uid)
  }, [db, user])
  const { data: profile, isLoading: isProfileLoading } = useDoc(userProfileRef)

  const restaurantId = profile?.restaurantId || null

  const staffRef = useMemoFirebase(() => {
    if (!db || !user || !restaurantId) return null
    return doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId, COLLECTION_NAMES.STAFF, user.uid)
  }, [db, user, restaurantId])
  const { data: staffProfile, isLoading: isStaffLoading } = useDoc(staffRef)

  React.useEffect(() => {
    if (process.env.NODE_ENV !== "production") {
      console.debug("[auth:restaurant-access]", {
        uid: user?.uid,
        allowedRoles,
        isUserLoading,
        isProfileLoading,
        isStaffLoading,
        restaurantId,
        userProfileRole: profile?.role ?? null,
        staffRole: staffProfile?.role ?? null,
        staffActive: staffProfile?.active ?? null,
      })
    }
  }, [
    allowedKey,
    allowedRoles,
    isProfileLoading,
    isStaffLoading,
    isUserLoading,
    profile?.role,
    restaurantId,
    staffProfile?.active,
    staffProfile?.role,
    user?.uid,
  ])

  return React.useMemo(() => {
    const role = staffProfile?.role || null
    const active = Boolean(staffProfile && staffProfile.active !== false)
    const isAllowed = Boolean(
      user &&
        restaurantId &&
        role &&
        active &&
        allowedRoles.includes(role)
    )

    return {
      user,
      isLoading: Boolean(
        isUserLoading ||
          (user && isProfileLoading) ||
          (user && restaurantId && isStaffLoading)
      ),
      restaurantId,
      role,
      active,
      isAllowed,
    }
  }, [
    allowedKey,
    allowedRoles,
    isProfileLoading,
    isStaffLoading,
    isUserLoading,
    restaurantId,
    staffProfile,
    user,
  ])
}
