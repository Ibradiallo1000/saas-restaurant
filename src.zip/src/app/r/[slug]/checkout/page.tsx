"use client"

import * as React from "react"
import { useParams, useRouter, useSearchParams } from "next/navigation"
import { addDoc, arrayUnion, collection, limit, query, serverTimestamp, setDoc, where } from "firebase/firestore"
import {
  ArrowLeft,
  CheckCircle2,
  Home,
  Hotel,
  Loader2,
  MapPin,
  Phone,
  Send,
  ShoppingBag,
  Store,
  Truck,
  User,
} from "lucide-react"

import { CartProvider, useCart } from "@/components/public/cart-context"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useCollection, useFirestore, useMemoFirebase } from "@/firebase"
import { useToast } from "@/hooks/use-toast"
import { COLLECTION_NAMES, ORDER_SOURCE, ORDER_STATUS, ORDER_TYPE, PAYMENT_STATUS } from "@/lib/constants"
import { getOrderTypeLabel } from "@/lib/order-utils"
import { companyCollection, companyDoc } from "@/lib/tenant-paths"
import { cn } from "@/lib/utils"
import type { OrderLocation, OrderType } from "@/types"

const ORDER_TYPE_OPTIONS = [
  { value: ORDER_TYPE.DINE_IN, label: "Sur place", helper: "Table restaurant", icon: Store },
  { value: ORDER_TYPE.TAKEAWAY, label: "A emporter", helper: "Retrait comptoir", icon: ShoppingBag },
  { value: ORDER_TYPE.DELIVERY, label: "Livraison", helper: "Adresse client", icon: Truck },
  { value: ORDER_TYPE.ROOM_SERVICE, label: "Chambre hotel", helper: "Service en chambre", icon: Hotel },
] as const

export default function CheckoutPageWrapper() {
  return (
    <CartProvider>
      <CheckoutPage />
    </CartProvider>
  )
}

function CheckoutPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const slug = params.slug as string
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()
  const { items, totalPrice, clearCart } = useCart()

  const [loading, setLoading] = React.useState(false)
  const [createdOrderId, setCreatedOrderId] = React.useState<string | null>(null)
  const initialTableNumber = searchParams.get("table") ?? ""
  const [orderType, setOrderType] = React.useState<OrderType>(initialTableNumber ? ORDER_TYPE.DINE_IN : ORDER_TYPE.TAKEAWAY)
  const [formData, setFormData] = React.useState({
    name: "",
    phone: "",
    tableNumber: initialTableNumber,
    roomNumber: "",
    address: "",
    note: "",
  })

  const restaurantQuery = useMemoFirebase(() => {
    if (!db || !slug) return null
    return query(collection(db, COLLECTION_NAMES.RESTAURANTS), where("slug", "==", slug), limit(1))
  }, [db, slug])
  const { data: restaurants } = useCollection(restaurantQuery)
  const restaurant = restaurants?.[0]

  const handleOrder = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!db || !restaurant || items.length === 0) return
    if (!restaurant.companyId) {
      toast({ variant: "destructive", title: "Erreur", description: "Restaurant non configure pour les commandes." })
      return
    }
    setLoading(true)

    try {
      const location = buildLocation(orderType, formData)
      const orderRef = await addDoc(companyCollection(db, restaurant.companyId, COLLECTION_NAMES.ORDERS), {
        companyId: restaurant.companyId,
        restaurantId: restaurant.id,
        customerName: formData.name,
        customerPhone: formData.phone,
        type: orderType,
        source: ORDER_SOURCE.QR,
        location,
        tableId: location.tableNumber ?? null,
        roomId: location.roomNumber ?? null,
        deliveryAddress: location.address ?? null,
        items: items.map((item) => ({
          productId: item.id,
          name: item.name,
          nameSnapshot: item.name,
          price: item.price,
          priceSnapshot: item.price,
          quantity: item.quantity,
        })),
        total: totalPrice,
        totalAmount: totalPrice,
        status: ORDER_STATUS.PENDING,
        paymentStatus: PAYMENT_STATUS.PENDING,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      })

      if (orderType === ORDER_TYPE.DINE_IN && location.tableNumber) {
        await setDoc(
          companyDoc(db, restaurant.companyId, "tableSessions", location.tableNumber),
          {
            tableNumber: location.tableNumber,
            status: "open",
            currentOrderIds: arrayUnion(orderRef.id),
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        )
      }

      for (const item of items) {
        await addDoc(collection(db, COLLECTION_NAMES.COMPANIES, restaurant.companyId, COLLECTION_NAMES.ORDERS, orderRef.id, COLLECTION_NAMES.ORDER_ITEMS), {
          productId: item.id,
          name: item.name,
          nameSnapshot: item.name,
          price: item.price,
          priceSnapshot: item.price,
          quantity: item.quantity,
          subtotal: item.price * item.quantity,
          createdAt: serverTimestamp(),
        })
      }

      setCreatedOrderId(orderRef.id)
      clearCart()
      toast({ title: "Commande envoyee", description: "La cuisine a recu votre demande." })
    } catch (error) {
      toast({ variant: "destructive", title: "Erreur", description: "Impossible de valider la commande." })
    } finally {
      setLoading(false)
    }
  }

  if (createdOrderId) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center space-y-6 p-6 text-center">
        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-green-100">
          <CheckCircle2 className="h-12 w-12 text-green-600" />
        </div>
        <div className="space-y-2">
          <h1 className="text-3xl font-black uppercase tracking-tighter">Merci</h1>
          <p className="text-muted-foreground">Votre commande est en preparation.</p>
        </div>
        <Button className="h-14 w-full max-w-sm rounded-2xl font-bold" onClick={() => router.push(`/order/${createdOrderId}/status?company=${restaurant?.companyId}`)}>
          Suivre ma commande
        </Button>
        <Button variant="ghost" className="h-12 w-full max-w-sm" onClick={() => router.push(`/r/${slug}`)}>
          Commander a nouveau
        </Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen space-y-6 bg-background p-4 md:p-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-xl bg-secondary/50">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-black uppercase tracking-tighter">Finaliser commande</h1>
          <p className="text-sm text-muted-foreground">Choisissez le mode puis confirmez.</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Card className="overflow-hidden rounded-2xl border-none shadow-xl">
            <CardHeader className="bg-primary p-5 text-white">
              <CardTitle className="flex items-center gap-2 uppercase">
                <ShoppingBag className="h-5 w-5" /> Recapitulatif
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 p-5">
              {items.map((item) => (
                <div key={item.id} className="flex items-center justify-between border-b py-2 last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="flex h-6 w-6 items-center justify-center rounded bg-primary/10 text-xs font-black text-primary">
                      {item.quantity}x
                    </span>
                    <span className="text-sm font-bold">{item.name}</span>
                  </div>
                  <span className="text-sm font-black">{item.price * item.quantity}{restaurant?.currency || "XOF"}</span>
                </div>
              ))}
              <div className="flex items-center justify-between pt-4 text-xl font-black text-primary">
                <span>Total</span>
                <span>{totalPrice}{restaurant?.currency || "XOF"}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <form onSubmit={handleOrder} className="space-y-6">
          <Card className="rounded-2xl border-none shadow-xl">
            <CardHeader className="p-5">
              <CardTitle className="text-xl font-black uppercase">1. Type de commande</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3 p-5 pt-0">
              {ORDER_TYPE_OPTIONS.map((option) => {
                const Icon = option.icon
                const active = orderType === option.value

                return (
                  <button
                    type="button"
                    key={option.value}
                    onClick={() => setOrderType(option.value)}
                    className={cn(
                      "min-h-24 rounded-xl border p-3 text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                      active ? "border-primary bg-primary text-white" : "bg-secondary/30 hover:bg-secondary"
                    )}
                  >
                    <Icon className="mb-2 h-5 w-5" />
                    <div className="text-sm font-black">{option.label}</div>
                    <div className={cn("mt-1 text-xs", active ? "text-white/75" : "text-muted-foreground")}>{option.helper}</div>
                  </button>
                )
              })}
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-none shadow-xl">
            <CardHeader className="p-5">
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="text-xl font-black uppercase">2. Informations</CardTitle>
                <Badge>{getOrderTypeLabel(orderType)}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 p-5 pt-0">
              <Field
                icon={User}
                label="Nom complet"
                required
                value={formData.name}
                placeholder="Ex: Ibrahim Diallo"
                onChange={(value) => setFormData((current) => ({ ...current, name: value }))}
              />

              <Field
                icon={Phone}
                label="Numero WhatsApp"
                required
                type="tel"
                value={formData.phone}
                placeholder="+223..."
                onChange={(value) => setFormData((current) => ({ ...current, phone: value }))}
              />

              {orderType === ORDER_TYPE.DINE_IN ? (
                <Field
                  icon={Store}
                  label="Numero de table"
                  required
                  value={formData.tableNumber}
                  placeholder="Ex: 4"
                  onChange={(value) => setFormData((current) => ({ ...current, tableNumber: value }))}
                />
              ) : null}

              {orderType === ORDER_TYPE.ROOM_SERVICE ? (
                <Field
                  icon={Hotel}
                  label="Numero de chambre"
                  required
                  value={formData.roomNumber}
                  placeholder="Ex: 204"
                  onChange={(value) => setFormData((current) => ({ ...current, roomNumber: value }))}
                />
              ) : null}

              {orderType === ORDER_TYPE.DELIVERY ? (
                <Field
                  icon={MapPin}
                  label="Adresse de livraison"
                  required
                  value={formData.address}
                  placeholder="Quartier, rue, point de repere"
                  onChange={(value) => setFormData((current) => ({ ...current, address: value }))}
                />
              ) : null}

              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Note optionnelle</Label>
                <Textarea
                  value={formData.note}
                  onChange={(event) => setFormData((current) => ({ ...current, note: event.target.value }))}
                  placeholder="Instructions utiles"
                  className="min-h-20 resize-none rounded-xl border-none bg-secondary/30"
                />
              </div>
            </CardContent>
          </Card>

          <Button
            type="submit"
            className="h-16 w-full rounded-2xl text-lg font-black uppercase shadow-[0_20px_50px_rgba(249,115,22,0.3)]"
            disabled={loading || items.length === 0}
          >
            {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : <>Envoyer la commande <Send className="ml-2 h-5 w-5" /></>}
          </Button>
        </form>
      </div>
    </div>
  )
}

function Field({
  icon: Icon,
  label,
  value,
  onChange,
  placeholder,
  required,
  type = "text",
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  onChange: (value: string) => void
  placeholder: string
  required?: boolean
  type?: string
}) {
  return (
    <div className="space-y-2">
      <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</Label>
      <div className="relative">
        <Icon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-primary" />
        <Input
          required={required}
          type={type}
          placeholder={placeholder}
          className="h-12 rounded-xl border-none bg-secondary/30 pl-10"
          value={value}
          onChange={(event) => onChange(event.target.value)}
        />
      </div>
    </div>
  )
}

function buildLocation(type: OrderType, data: {
  tableNumber: string
  roomNumber: string
  address: string
  note: string
}): OrderLocation {
  return {
    tableNumber: type === ORDER_TYPE.DINE_IN ? data.tableNumber.trim() : undefined,
    roomNumber: type === ORDER_TYPE.ROOM_SERVICE ? data.roomNumber.trim() : undefined,
    address: type === ORDER_TYPE.DELIVERY ? data.address.trim() : undefined,
    note: data.note.trim() || undefined,
  }
}
