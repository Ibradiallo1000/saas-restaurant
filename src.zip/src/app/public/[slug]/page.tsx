"use client"

import * as React from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import { ShoppingBag, Plus, Minus, ChevronRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Skeleton } from "@/components/ui/skeleton"
import { CartProvider, useCart } from "@/components/public/cart-context"
import { useMenu } from "@/hooks/useMenu"
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, where, limit } from "firebase/firestore"
import { COLLECTION_NAMES } from "@/lib/constants"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function PublicPageWrapper() {
  return (
    <CartProvider>
      <PublicMenuPage />
    </CartProvider>
  )
}

function PublicMenuPage() {
  const params = useParams()
  const slug = params.slug as string
  const db = useFirestore()

  const restaurantQuery = useMemoFirebase(() => {
    if (!db || !slug) return null
    return query(collection(db, COLLECTION_NAMES.RESTAURANTS), where("slug", "==", slug), limit(1))
  }, [db, slug])
  const { data: restaurants, isLoading: isResLoading } = useCollection(restaurantQuery)
  const restaurant = restaurants?.[0]

  const { items: products, categories } = useMenu(restaurant?.id)
  const [activeCategory, setActiveCategory] = React.useState<string | null>(null)

  if (isResLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    )
  }

  if (!restaurant) {
    return (
      <div className="flex min-h-screen items-center justify-center font-bold">
        Établissement non trouvé
      </div>
    )
  }

  const filteredProducts = activeCategory
    ? products.filter((p) => p.categoryId === activeCategory)
    : products

  return (
    <div className="min-h-screen bg-background pb-32">
      <header className="sticky top-0 z-40 w-full border-b bg-background/80 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-lg bg-primary/10 font-black text-primary">
              {restaurant.logoUrl ? (
                <Image src={restaurant.logoUrl} alt={restaurant.name} width={40} height={40} className="object-cover" />
              ) : (
                restaurant.name.charAt(0)
              )}
            </div>
            <div>
              <h1 className="text-sm font-black uppercase italic leading-none">{restaurant.name}</h1>
              <div className="mt-1 flex items-center gap-1">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-green-500" />
                <span className="text-[10px] font-bold uppercase tracking-tight text-muted-foreground">Cuisine Ouverte</span>
              </div>
            </div>
          </div>
          <CartButton />
        </div>
      </header>

      <div className="sticky top-[57px] z-30 border-b bg-background/95 shadow-sm">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex gap-2 p-3">
            <Button
              variant={activeCategory === null ? "default" : "secondary"}
              size="sm"
              className={cn("h-8 rounded-full text-[11px] font-bold", activeCategory === null && "bg-primary")}
              onClick={() => setActiveCategory(null)}
            >
              Tout voir
            </Button>
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={activeCategory === cat.id ? "default" : "secondary"}
                size="sm"
                className={cn("h-8 rounded-full text-[11px] font-bold", activeCategory === cat.id && "bg-primary")}
                onClick={() => setActiveCategory(cat.id)}
              >
                {cat.name}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" className="hidden" />
        </ScrollArea>
      </div>

      <main className="mt-6 px-4">
        <div className="grid grid-cols-2 gap-3">
          {filteredProducts.length === 0 ? (
            <div className="col-span-2 py-20 text-center text-muted-foreground">Aucun produit disponible</div>
          ) : (
            filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} currency={restaurant.currency || "XOF"} />
            ))
          )}
        </div>
      </main>

      <CartBottomBar slug={slug} currency={restaurant.currency || "XOF"} />
    </div>
  )
}

function ProductCard({ product, currency }: { product: import("@/types/index").MenuItem; currency: string }) {
  const { addItem, items, updateQuantity } = useCart()
  const cartItem = items.find((i) => i.id === product.id)

  return (
    <Card className="group overflow-hidden rounded-2xl border border-primary/5 shadow-sm transition-all active:scale-95">
      <div className="relative aspect-square cursor-pointer overflow-hidden bg-muted">
        <Image
          src={product.imageUrl || `https://picsum.photos/seed/${product.id}/400/400`}
          alt={product.name}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 50vw, 33vw"
        />
      </div>
      <CardContent className="p-3">
        <h3 className="line-clamp-2 h-7 text-[11px] font-bold leading-tight">{product.name}</h3>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-[13px] font-black italic leading-none text-primary">
            {product.price.toLocaleString()}
            {currency}
          </span>

          {cartItem ? (
            <div className="flex items-center gap-2 rounded-full bg-primary/10 px-1 py-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded-full bg-primary text-white"
                onClick={() => updateQuantity(product.id, cartItem.quantity - 1)}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <span className="text-xs font-black text-primary">{cartItem.quantity}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded-full bg-primary text-white"
                onClick={() => updateQuantity(product.id, cartItem.quantity + 1)}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Button
              variant="secondary"
              size="icon"
              className="h-7 w-7 rounded-full bg-primary/10 text-primary transition-colors hover:bg-primary hover:text-white"
              onClick={() =>
                addItem(
                  {
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    imageUrl: product.imageUrl,
                  },
                  1
                )
              }
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function CartButton() {
  const { totalItems } = useCart()
  return (
    <Button variant="ghost" size="icon" className="relative h-10 w-10 rounded-xl bg-secondary/50">
      <ShoppingBag className="h-5 w-5 text-primary" />
      {totalItems > 0 && (
        <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full border-2 border-background bg-primary text-[9px] font-black text-white animate-in zoom-in">
          {totalItems}
        </span>
      )}
    </Button>
  )
}

function CartBottomBar({ slug, currency }: { slug: string; currency: string }) {
  const { totalItems, totalPrice } = useCart()

  if (totalItems === 0) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 animate-in slide-in-from-bottom-full duration-500 p-4">
      <Link
        href={`/public/${slug}/checkout`}
        className="mx-auto flex max-w-md items-center justify-between rounded-3xl bg-primary p-4 text-white shadow-[0_20px_50px_rgba(249,115,22,0.4)] transition-all active:scale-[0.98]"
      >
        <div className="flex flex-col">
          <span className="text-[9px] font-black uppercase tracking-widest opacity-80">
            {totalItems} ARTICLE{totalItems > 1 ? "S" : ""}
          </span>
          <span className="text-xl font-black italic tracking-tighter">
            {totalPrice.toLocaleString()}
            {currency}
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-2xl bg-white/20 px-6 py-3 text-xs font-black uppercase italic">
          Commander <ChevronRight className="h-4 w-4" />
        </div>
      </Link>
    </div>
  )
}

