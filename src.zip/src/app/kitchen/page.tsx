"use client"

import { ChefHat, Loader2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useCurrentUser } from "@/hooks/use-current-user"
import { useOrders } from "@/hooks/useOrders"
import { updateOrderStatus } from "@/services/orderService"
import type { Order, OrderStatus } from "@/types/index"

const COLUMNS: { status: OrderStatus; title: string }[] = [
  { status: "nouvelle", title: "Nouvelles" },
  { status: "en_preparation", title: "En préparation" },
  { status: "prete", title: "Prêtes" },
]

export default function KitchenPage() {
  const { companyId } = useCurrentUser()
  const orders = useOrders(companyId ?? undefined, [
    "nouvelle",
    "en_preparation",
    "prete",
  ])

  if (!companyId) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950 p-6 text-center text-white">
        <div>
          <ChefHat className="mx-auto mb-4 h-10 w-10 text-white/40" />
          <h1 className="text-2xl font-bold">Connexion requise</h1>
          <p className="mt-2 text-white/50">Veuillez vous connecter pour accéder au KDS.</p>
        </div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-zinc-950 p-4 text-white">
      <header className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="flex items-center gap-2 text-3xl font-bold tracking-tight">
            <ChefHat className="h-8 w-8 text-primary" />
            KDS
          </h1>
          <p className="text-sm text-white/50">Commandes en temps réel</p>
        </div>
        <Badge className="bg-white/10 text-white">{orders.length} commandes</Badge>
      </header>

      <div className="grid h-[calc(100vh-96px)] grid-cols-1 gap-4 lg:grid-cols-3">
        {COLUMNS.map((column) => {
          const columnOrders = orders.filter((o) => o.status === column.status)
          return (
            <section
              key={column.status}
              className="flex min-h-0 flex-col rounded-lg border border-white/10 bg-white/[0.04]"
            >
              <div className="flex min-h-14 items-center justify-between border-b border-white/10 px-4">
                <h2 className="font-semibold">{column.title}</h2>
                <span className="rounded-full bg-white/10 px-2 py-1 text-xs font-bold">
                  {columnOrders.length}
                </span>
              </div>
              <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3">
                {columnOrders.map((order) => (
                  <KitchenOrderCard
                    key={order.id}
                    order={order}
                    companyId={companyId}
                  />
                ))}
              </div>
            </section>
          )
        })}
      </div>
    </main>
  )
}

function KitchenOrderCard({ order, companyId }: { order: Order; companyId: string }) {
  const nextAction = getNextAction(order.status)

  return (
    <Card className="border-2 border-border bg-zinc-900 text-white">
      <CardHeader className="space-y-2 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-xl">
              {order.table ? `Table ${order.table}` : "À emporter"}
            </CardTitle>
            <Badge className={statusClass(order.status)}>{order.status}</Badge>
          </div>
          <div className="text-right">
            <div className="font-bold">{order.total.toLocaleString()} FCFA</div>
            <div className="text-xs text-white/50">
              {order.items.reduce((s, i) => s + i.quantity, 0)} article
              {order.items.reduce((s, i) => s + i.quantity, 0) > 1 ? "s" : ""}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 p-4 pt-0">
        <div className="space-y-2 text-lg font-semibold">
          {order.items.map((item, idx) => (
            <div
              key={idx}
              className="flex justify-between gap-3 rounded-md bg-zinc-800 p-3"
            >
              <span>{item.name}</span>
              <span>x{item.quantity}</span>
            </div>
          ))}
        </div>

        {nextAction ? (
          <Button
            className="h-11 w-full"
            onClick={() => updateOrderStatus(companyId, order.id, nextAction.status)}
          >
            {nextAction.label}
          </Button>
        ) : null}
      </CardContent>
    </Card>
  )
}

function getNextAction(status: OrderStatus): { status: OrderStatus; label: string } | null {
  switch (status) {
    case "nouvelle":
      return { status: "en_preparation", label: "Commencer" }
    case "en_preparation":
      return { status: "prete", label: "Prêt" }
    default:
      return null
  }
}

function statusClass(status: OrderStatus) {
  switch (status) {
    case "nouvelle":
      return "bg-blue-600"
    case "en_preparation":
      return "bg-orange-500"
    case "prete":
      return "bg-green-600"
    case "servie":
      return "bg-emerald-700"
    case "annulee":
      return "bg-red-600"
    default:
      return "bg-muted text-muted-foreground"
  }
}

