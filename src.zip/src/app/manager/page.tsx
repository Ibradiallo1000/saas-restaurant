"use client"

import { BarChart3, ChefHat, Clock, DollarSign, Package, TrendingUp, Users } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useCurrentUser } from "@/hooks/use-current-user"
import { useOrders } from "@/hooks/useOrders"
import type { OrderStatus } from "@/types/index"

export default function ManagerPage() {
  const { companyId } = useCurrentUser()
  const orders = useOrders(companyId ?? undefined)

  if (!companyId) {
    return (
      <div className="flex min-h-screen items-center justify-center p-6 text-center">
        <div>
          <BarChart3 className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
          <h1 className="text-2xl font-bold">Connexion requise</h1>
          <p className="mt-2 text-muted-foreground">Veuillez vous connecter pour accéder au tableau de bord.</p>
        </div>
      </div>
    )
  }

  const kpi = computeKPI(orders)

  return (
    <main className="min-h-screen space-y-6 p-4 md:p-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Manager</h1>
        <p className="text-sm text-muted-foreground">KPI et suivi temps réel</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard title="Commandes du jour" value={kpi.totalToday} icon={Package} />
        <MetricCard title="Chiffre d'affaires" value={`${kpi.revenue.toLocaleString()} FCFA`} icon={DollarSign} />
        <MetricCard title="En cuisine" value={kpi.inKitchen} icon={ChefHat} />
        <MetricCard title="Prêtes" value={kpi.ready} icon={Clock} />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" />
              Répartition par statut
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {(["nouvelle", "en_preparation", "prete", "servie", "annulee"] as OrderStatus[]).map((status) => {
              const count = orders.filter((o) => o.status === status).length
              return (
                <div key={status} className="flex items-center justify-between">
                  <span className="text-sm font-medium capitalize">{status.replace("_", " ")}</span>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              )
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Users className="h-4 w-4 text-primary" />
              Commandes récentes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {orders.slice(0, 5).map((order) => (
              <div key={order.id} className="flex items-center justify-between rounded-md border p-3">
                <div className="space-y-1">
                  <div className="text-sm font-medium">
                    {order.table ? `Table ${order.table}` : "À emporter"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {order.items.reduce((s, i) => s + i.quantity, 0)} articles — {order.total.toLocaleString()} FCFA
                  </div>
                </div>
                <Badge className={statusBadgeClass(order.status)}>{order.status}</Badge>
              </div>
            ))}
            {orders.length === 0 && (
              <div className="text-sm text-muted-foreground">Aucune commande</div>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

function MetricCard({
  title,
  value,
  icon: Icon,
}: {
  title: string
  value: string | number
  icon: React.ComponentType<{ className?: string }>
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  )
}

function computeKPI(orders: import("@/types/index").Order[]) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const totalToday = orders.filter((o) => o.createdAt >= today.getTime()).length
  const revenue = orders
    .filter((o) => o.status !== "annulee")
    .reduce((sum, o) => sum + o.total, 0)
  const inKitchen = orders.filter((o) => o.status === "nouvelle" || o.status === "en_preparation").length
  const ready = orders.filter((o) => o.status === "prete").length

  return { totalToday, revenue, inKitchen, ready }
}

function statusBadgeClass(status: OrderStatus) {
  switch (status) {
    case "nouvelle":
      return "bg-blue-600 text-white"
    case "en_preparation":
      return "bg-orange-500 text-white"
    case "prete":
      return "bg-green-600 text-white"
    case "servie":
      return "bg-emerald-700 text-white"
    case "annulee":
      return "bg-red-600 text-white"
    default:
      return "bg-muted text-muted-foreground"
  }
}

