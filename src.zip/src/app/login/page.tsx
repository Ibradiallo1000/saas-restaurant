"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { signInWithEmailAndPassword } from "firebase/auth"
import { Loader2, LogIn, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { useAuth, useUser } from "@/firebase"

export default function LoginPage() {
  const auth = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const { user, isUserLoading } = useUser()

  const [email, setEmail] = React.useState("")
  const [password, setPassword] = React.useState("")
  const [loading, setLoading] = React.useState(false)

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!email || !password) return

    setLoading(true)

    try {
      await signInWithEmailAndPassword(auth, email, password)
      router.replace("/")
    } catch (error: any) {
      setLoading(false)
      console.error("Login Error:", error.code)
      toast({
        variant: "destructive",
        title: "Erreur de connexion",
        description: "Identifiants incorrects. Verifiez votre email et mot de passe.",
      })
    }
  }

  if (isUserLoading || user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="animate-pulse text-xs font-black uppercase tracking-widest">
          Redirection...
        </p>
      </div>
    )
  }

  return (
    <div className="flex min-h-[80vh] items-center justify-center px-4 animate-in fade-in duration-500">
      <Card className="w-full max-w-md overflow-hidden rounded-3xl border-none shadow-2xl">
        <CardHeader className="bg-primary py-10 text-center text-primary-foreground">
          <div className="mb-4 flex justify-center">
            <Zap className="h-10 w-10" />
          </div>
          <CardTitle className="text-3xl font-black italic uppercase tracking-tighter">
            Portail GastronomeAI
          </CardTitle>
          <CardDescription className="text-white/80">Entrez vos acces securises</CardDescription>
        </CardHeader>
        <div className="p-8">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="login-email">Email professionnel</Label>
              <Input
                id="login-email"
                type="email"
                required
                placeholder="nom@exemple.com"
                className="h-12 rounded-xl border-none bg-secondary/50"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="login-password">Mot de passe</Label>
              <Input
                id="login-password"
                type="password"
                required
                className="h-12 rounded-xl border-none bg-secondary/50"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>
            <Button
              type="submit"
              className="h-14 w-full text-lg font-black uppercase italic shadow-lg"
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <LogIn className="mr-2 h-5 w-5" />
              )}
              {loading ? "Verification..." : "Se connecter"}
            </Button>
          </form>
        </div>
      </Card>
    </div>
  )
}
