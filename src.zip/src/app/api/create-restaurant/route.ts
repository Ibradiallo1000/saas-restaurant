import { NextRequest, NextResponse } from "next/server"

import { requireSuperAdmin } from "@/server/auth/api-auth"
import { getAdminAuth, getAdminFirestore } from "@/server/firebase-admin"
import { writeCaughtErrorLog } from "@/server/error-log"
import {
  createRestaurantOnboarding,
  OnboardingError,
  type CreateRestaurantInput,
} from "../../../../server/services/create-restaurant.service"

export const runtime = "nodejs"

export async function POST(request: NextRequest) {
  const auth = await requireSuperAdmin(request)
  if (!auth.ok) return auth.response

  try {
    const input = (await request.json()) as CreateRestaurantInput
    await assertOwnerAuthUserMatches(input)

    const result = await createRestaurantOnboarding(getAdminFirestore(), input, {
      actorId: auth.decodedToken.uid,
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    if (error instanceof OnboardingError) {
      return NextResponse.json({ error: error.message }, { status: error.statusCode })
    }

    console.error("CREATE_RESTAURANT failed", error)
    await writeCaughtErrorLog(error, {
      route: "/api/create-restaurant",
      actorId: auth.decodedToken.uid,
    })

    return NextResponse.json({ error: "Creation restaurant impossible." }, { status: 500 })
  }
}

async function assertOwnerAuthUserMatches(input: CreateRestaurantInput): Promise<void> {
  const email = typeof input?.email === "string" ? input.email.trim().toLowerCase() : ""
  const userId = typeof input?.userId === "string" ? input.userId.trim() : ""

  if (!userId) {
    throw new OnboardingError("userId manquant.", 400)
  }

  const authUser = await getAdminAuth()
    .getUser(userId)
    .catch(() => null)

  if (!authUser) {
    throw new OnboardingError("Utilisateur Firebase Auth introuvable.", 400)
  }

  if (authUser.email && authUser.email.toLowerCase() !== email) {
    throw new OnboardingError("L'email ne correspond pas au userId Firebase Auth.", 400)
  }
}
