export default function POSLayout({ children }: { children: React.ReactNode }) {
  return <section className="min-h-screen bg-background">{children}</section>
}
