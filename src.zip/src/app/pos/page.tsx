"use client"

import { Loader2, UtensilsCrossed } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useCurrentUser } from "@/hooks/use-current-user"
import { useOrders } from "@/hooks/useOrders"
import { updateOrderStatus } from "@/services/orderService"
import type { Order } from "@/types/index"

export default function POSPage() {
  const { companyId } = useCurrentUser()
  const orders = useOrders(companyId ?? undefined, ["prete"])

  if (!companyId) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950 p-6 text-white">
        <div>
          <UtensilsCrossed className="mx-auto mb-4 h-10 w-10 text-white/40" />
          <h1 className="text-2xl font-bold">Connexion requise</h1>
          <p className="mt-2 text-white/50">Veuillez vous connecter pour accéder à la caisse.</p>
        </div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-zinc-950 p-4 text-white">
      <header className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="flex items-center gap-2 text-3xl font-bold tracking-tight">
            <UtensilsCrossed className="h-8 w-8 text-primary" />
            Caisse
          </h1>
          <p className="text-sm text-white/50">Commandes prêtes à servir</p>
        </div>
        <Badge className="bg-white/10 text-white">{orders.length} prête{orders.length > 1 ? "s" : ""}</Badge>
      </header>

      {orders.length === 0 ? (
        <div className="flex h-64 items-center justify-center rounded-md border border-dashed border-white/10 text-sm text-white/50">
          Aucune commande prête
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {orders.map((order) => (
            <PosOrderCard key={order.id} order={order} companyId={companyId} />
          ))}
        </div>
      )}
    </main>
  )
}

function PosOrderCard({ order, companyId }: { order: Order; companyId: string }) {
  return (
    <Card className="border-2 border-green-600 bg-zinc-900 text-white">
      <CardHeader className="space-y-2 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-xl">
              {order.table ? `Table ${order.table}` : "À emporter"}
            </CardTitle>
            <Badge className="bg-green-600">{order.status}</Badge>
          </div>
          <div className="text-right">
            <div className="font-bold">{order.total.toLocaleString()} FCFA</div>
            <div className="text-xs text-white/50">
              {order.items.reduce((s, i) => s + i.quantity, 0)} article
              {order.items.reduce((s, i) => s + i.quantity, 0) > 1 ? "s" : ""}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 p-4 pt-0">
        <div className="space-y-2 text-sm">
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between gap-3 rounded-md bg-zinc-800 p-3">
              <span>{item.name}</span>
              <span>x{item.quantity}</span>
            </div>
          ))}
        </div>
        <Button
          className="h-11 w-full bg-emerald-600 hover:bg-emerald-700"
          onClick={() => updateOrderStatus(companyId, order.id, "servie")}
        >
          Servi
        </Button>
      </CardContent>
    </Card>
  )
}

