import type { Metadata } from 'next';
import './globals.css';
import { AppShell } from '@/components/layout/app-shell';
import { Toaster } from '@/components/ui/toaster';
import { PlatformProvider } from '@/contexts/platform-context';
import { CurrentUserProvider } from '@/contexts/current-user-context';
import { ThemeProvider } from '@/contexts/theme-context';
import { FirebaseClientProvider } from '@/firebase/client-provider';

export const metadata: Metadata = {
  title: 'GastronomeAI - SaaS Foundation',
  description: 'Scalable multi-tenant architecture for modern hospitality.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased">
        <FirebaseClientProvider>
          <ThemeProvider>
            <PlatformProvider>
              <CurrentUserProvider>
                <AppShell>{children}</AppShell>
              </CurrentUserProvider>
            </PlatformProvider>
          </ThemeProvider>
          <Toaster />
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
