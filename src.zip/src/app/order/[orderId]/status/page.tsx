"use client"

import * as React from "react"
import { useParams, useSearchParams } from "next/navigation"
import { doc } from "firebase/firestore"
import { Bell, CheckCircle2, ChefHat, Clock, Sparkles } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useDoc, useFirestore } from "@/firebase"
import { COLLECTION_NAMES, ORDER_STATUS } from "@/lib/constants"
import { getOrderLocationLabel, getOrderTypeLabel, getOrderTotal } from "@/lib/order-utils"
import { cn } from "@/lib/utils"
import type { RestaurantOrder } from "@/types"

export default function OrderStatusPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const db = useFirestore()
  const orderId = params.orderId as string
  const companyId = searchParams.get("company")

  const orderRef = React.useMemo(() => {
    if (!db || !orderId) return null
    if (companyId) {
      return doc(db, COLLECTION_NAMES.COMPANIES, companyId, COLLECTION_NAMES.ORDERS, orderId)
    }
    return doc(db, COLLECTION_NAMES.ORDERS, orderId)
  }, [companyId, db, orderId])

  const { data: order, isLoading } = useDoc<RestaurantOrder>(orderRef)

  if (isLoading) return <div className="flex justify-center p-20 animate-pulse">Suivi de commande...</div>
  if (!order) return <div className="text-center p-20 font-bold">Commande introuvable</div>

  const steps = [
    { id: ORDER_STATUS.PENDING, label: "Commande recue", icon: Clock },
    { id: ORDER_STATUS.ACCEPTED, label: "Acceptee", icon: CheckCircle2 },
    { id: ORDER_STATUS.PREPARING, label: "En preparation", icon: ChefHat },
    { id: ORDER_STATUS.READY, label: "Prete", icon: Bell },
    { id: ORDER_STATUS.SERVED, label: "Servie", icon: CheckCircle2 },
  ] as const

  return (
    <div className="mx-auto max-w-md space-y-8 px-4 py-10">
      <div className="space-y-4 text-center">
        <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
          <Sparkles className="h-3 w-3" /> Suivi live
        </div>
        <h1 className="text-4xl font-black uppercase tracking-tighter text-primary">Votre commande</h1>
        <p className="font-medium text-muted-foreground">
          #{order.id.slice(-6)} - {getOrderTotal(order).toLocaleString()} FCFA
        </p>
        <p className="text-sm text-muted-foreground">
          {getOrderTypeLabel(order.type)} - {getOrderLocationLabel(order)}
        </p>
      </div>

      <Card className="overflow-hidden border-none shadow-2xl">
        <CardHeader className="bg-primary p-8 text-center text-primary-foreground">
          <div className="mb-4">
            <Progress value={getProgress(order.status)} className="h-3 bg-white/20" />
          </div>
          <CardTitle className="text-2xl font-black uppercase">
            {steps.find((step) => step.id === order.status)?.label || "En cours"}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <div className="space-y-6">
            {steps.map((step) => {
              const isPast = getProgress(order.status) >= getProgress(step.id)
              const isCurrent = order.status === step.id
              const Icon = step.icon

              return (
                <div
                  key={step.id}
                  className={cn("flex items-center gap-4 transition-all duration-500", isPast ? "opacity-100" : "opacity-30")}
                >
                  <div
                    className={cn(
                      "flex h-12 w-12 items-center justify-center rounded-2xl shadow-lg transition-all",
                      isCurrent ? "scale-110 animate-pulse bg-primary text-white" : isPast ? "bg-green-500 text-white" : "bg-muted"
                    )}
                  >
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <p className={cn("font-black uppercase tracking-wider", isCurrent ? "text-lg text-primary" : "text-sm")}>
                      {step.label}
                    </p>
                    {isCurrent ? <p className="text-xs font-medium italic text-muted-foreground">Etape actuelle</p> : null}
                  </div>
                  {isPast && !isCurrent ? <CheckCircle2 className="h-5 w-5 text-green-500" /> : null}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-xs italic text-muted-foreground">
        Cette page se met a jour automatiquement.
      </p>
    </div>
  )
}

function getProgress(status: string) {
  switch (status) {
    case ORDER_STATUS.PENDING:
      return 20
    case ORDER_STATUS.ACCEPTED:
      return 35
    case ORDER_STATUS.PREPARING:
      return 55
    case ORDER_STATUS.READY:
      return 80
    case ORDER_STATUS.SERVED:
    case ORDER_STATUS.DELIVERED:
      return 100
    default:
      return 10
  }
}
