"use client"

import type { Firestore } from "firebase/firestore"

import { createRestaurant } from "@/services/onboarding-api.service"

export interface RestaurantData {
  name: string
  slug?: string
  country: string
  currency?: string
  userId?: string
  token?: string
}

export class RestaurantService {
  constructor(private db: Firestore) {}

  async createRestaurantForOwner(ownerEmail: string, data: RestaurantData) {
    if (!data.slug || !data.userId) {
      throw new Error("slug et userId sont requis pour creer un restaurant.")
    }

    const result = await createRestaurant(
      {
        name: data.name,
        email: ownerEmail,
        slug: data.slug,
        userId: data.userId,
      },
      data.token
    )

    return result.restaurantId
  }
}
