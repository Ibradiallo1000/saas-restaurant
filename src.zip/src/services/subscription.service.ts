"use client"

import {
  collection,
  deleteField,
  doc,
  Firestore,
  getDocs,
  getFirestore,
  query,
  runTransaction,
  serverTimestamp,
  Timestamp,
  where,
} from "firebase/firestore"
import { getApp, getApps, initializeApp } from "firebase/app"

import { firebaseConfig } from "@/firebase/config"
import {
  COLLECTION_NAMES,
  DEFAULT_BILLING_PERIOD_DAYS,
  SUBSCRIPTION_PLAN,
  SUBSCRIPTION_STATUS,
  TRIAL_DAYS,
} from "@/lib/constants"
import { logClientError } from "@/services/client-error-log.service"
import type { RestaurantPlan } from "@/types"

const PLAN_PRICES: Record<RestaurantPlan, number> = {
  [SUBSCRIPTION_PLAN.TRIAL]: 0,
  [SUBSCRIPTION_PLAN.BASIC]: 15000,
  [SUBSCRIPTION_PLAN.PRO]: 30000,
  [SUBSCRIPTION_PLAN.CUSTOM]: 0,
  business: 50000,
}

export function getPlanPrice(plan: RestaurantPlan): number {
  return PLAN_PRICES[plan] ?? 0
}

export function updateSubscriptionPlan(restaurantId: string, plan: RestaurantPlan): Promise<void>
export function updateSubscriptionPlan(
  db: Firestore,
  restaurantId: string,
  plan: RestaurantPlan
): Promise<void>
export async function updateSubscriptionPlan(
  dbOrRestaurantId: Firestore | string,
  restaurantIdOrPlan: string | RestaurantPlan,
  maybePlan?: RestaurantPlan
) {
  const db = typeof dbOrRestaurantId === "string" ? getDefaultFirestore() : dbOrRestaurantId
  const restaurantId =
    typeof dbOrRestaurantId === "string" ? dbOrRestaurantId : restaurantIdOrPlan
  const plan = typeof dbOrRestaurantId === "string" ? restaurantIdOrPlan : maybePlan

  if (!plan) {
    throw new Error("Plan requis.")
  }

  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId as string)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId as string)
      const now = new Date()

      if (plan === SUBSCRIPTION_PLAN.TRIAL) {
        const trialEndsAt = Timestamp.fromDate(addDays(now, TRIAL_DAYS))

        transaction.update(subscriptionRef, {
          plan,
          status: SUBSCRIPTION_STATUS.TRIAL,
          billingStatus: "manual",
          currentPeriodStart: Timestamp.fromDate(now),
          currentPeriodEnd: trialEndsAt,
          trialEndsAt,
          graceEndsAt: deleteField(),
          isManual: true,
          updatedAt: serverTimestamp(),
        })
      } else {
        transaction.update(subscriptionRef, {
          plan,
          status: SUBSCRIPTION_STATUS.ACTIVE,
          billingStatus: "paid",
          currentPeriodStart: Timestamp.fromDate(now),
          currentPeriodEnd: Timestamp.fromDate(addDays(now, DEFAULT_BILLING_PERIOD_DAYS)),
          trialEndsAt: deleteField(),
          graceEndsAt: deleteField(),
          isManual: true,
          updatedAt: serverTimestamp(),
        })
      }

      transaction.update(restaurantRef, {
        status: "active",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "updateSubscriptionPlan", restaurantId as string, { plan })
    throw error
  }
}

export async function activateSubscription(
  db: Firestore,
  restaurantId: string,
  currentPeriodEnd?: Date
) {
  const endDate = currentPeriodEnd ?? addDays(new Date(), DEFAULT_BILLING_PERIOD_DAYS)

  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId)

      transaction.update(subscriptionRef, {
        status: SUBSCRIPTION_STATUS.ACTIVE,
        billingStatus: "paid",
        currentPeriodStart: Timestamp.fromDate(new Date()),
        currentPeriodEnd: Timestamp.fromDate(endDate),
        trialEndsAt: deleteField(),
        graceEndsAt: deleteField(),
        isManual: true,
        updatedAt: serverTimestamp(),
      })
      transaction.update(restaurantRef, {
        status: "active",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "activateSubscription", restaurantId)
    throw error
  }
}

export async function setSubscriptionCurrentPeriodEnd(
  db: Firestore,
  restaurantId: string,
  currentPeriodEnd: Date
) {
  assertFutureDate(currentPeriodEnd, "La date de fin doit etre dans le futur.")

  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId)

      transaction.update(subscriptionRef, {
        status: SUBSCRIPTION_STATUS.ACTIVE,
        billingStatus: "manual",
        currentPeriodStart: Timestamp.fromDate(new Date()),
        currentPeriodEnd: Timestamp.fromDate(currentPeriodEnd),
        trialEndsAt: deleteField(),
        graceEndsAt: deleteField(),
        isManual: true,
        updatedAt: serverTimestamp(),
      })
      transaction.update(restaurantRef, {
        status: "active",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "setSubscriptionCurrentPeriodEnd", restaurantId, {
      currentPeriodEnd: currentPeriodEnd.toISOString(),
    })
    throw error
  }
}

export async function activateGracePeriod(
  db: Firestore,
  restaurantId: string,
  graceEndsAt: Date
) {
  assertFutureDate(graceEndsAt, "La date de fin de tolerance doit etre dans le futur.")

  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId)

      transaction.update(subscriptionRef, {
        status: SUBSCRIPTION_STATUS.GRACE,
        graceEndsAt: Timestamp.fromDate(graceEndsAt),
        isManual: true,
        updatedAt: serverTimestamp(),
      })
      transaction.update(restaurantRef, {
        status: "active",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "activateGracePeriod", restaurantId, {
      graceEndsAt: graceEndsAt.toISOString(),
    })
    throw error
  }
}

export async function grantLifetimeAccess(db: Firestore, restaurantId: string) {
  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId)

      transaction.update(subscriptionRef, {
        plan: SUBSCRIPTION_PLAN.CUSTOM,
        status: SUBSCRIPTION_STATUS.LIFETIME,
        billingStatus: "manual",
        currentPeriodStart: Timestamp.fromDate(new Date()),
        currentPeriodEnd: deleteField(),
        trialEndsAt: deleteField(),
        graceEndsAt: deleteField(),
        isManual: true,
        updatedAt: serverTimestamp(),
      })
      transaction.update(restaurantRef, {
        status: "active",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "grantLifetimeAccess", restaurantId)
    throw error
  }
}

export async function suspendSubscription(db: Firestore, restaurantId: string) {
  try {
    await runTransaction(db, async (transaction) => {
      const subscriptionRef = await findSubscriptionRef(db, restaurantId)
      const restaurantRef = doc(db, COLLECTION_NAMES.RESTAURANTS, restaurantId)

      transaction.update(subscriptionRef, {
        status: SUBSCRIPTION_STATUS.SUSPENDED,
        updatedAt: serverTimestamp(),
      })
      transaction.update(restaurantRef, {
        status: "suspended",
        updatedAt: serverTimestamp(),
      })
    })
  } catch (error) {
    await logSubscriptionError(db, error, "suspendSubscription", restaurantId)
    throw error
  }
}

async function findSubscriptionRef(db: Firestore, restaurantId: string) {
  const fallbackQuery = await getDocs(
    query(collection(db, COLLECTION_NAMES.SUBSCRIPTIONS), where("restaurantId", "==", restaurantId))
  )

  if (!fallbackQuery.empty) {
    return doc(db, COLLECTION_NAMES.SUBSCRIPTIONS, fallbackQuery.docs[0].id)
  }

  return doc(db, COLLECTION_NAMES.SUBSCRIPTIONS, restaurantId)
}

function assertFutureDate(date: Date, message: string) {
  if (Number.isNaN(date.getTime()) || date.getTime() <= Date.now()) {
    throw new Error(message)
  }
}

function addDays(date: Date, days: number) {
  const nextDate = new Date(date)
  nextDate.setDate(nextDate.getDate() + days)
  return nextDate
}

function getDefaultFirestore(): Firestore {
  const app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  return getFirestore(app)
}

async function logSubscriptionError(
  db: Firestore,
  error: unknown,
  scope: string,
  restaurantId: string,
  context?: Record<string, unknown>
) {
  await logClientError(db, error, {
    scope,
    restaurantId,
    ...(context ?? {}),
  })
}
