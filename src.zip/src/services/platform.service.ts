"use client"

import { doc, Firestore, getDoc, serverTimestamp, setDoc } from "firebase/firestore"

import { COLLECTION_NAMES } from "@/lib/constants"
import type { PlatformSettings } from "@/types"

export class PlatformService {
  constructor(private db: Firestore) {}

  async getConfig(): Promise<PlatformSettings | null> {
    const docRef = doc(this.db, COLLECTION_NAMES.PLATFORM_SETTINGS, "default")
    const snap = await getDoc(docRef)

    if (!snap.exists()) return null

    return snap.data() as PlatformSettings
  }

  async updateConfig(data: Partial<PlatformSettings>) {
    const docRef = doc(this.db, COLLECTION_NAMES.PLATFORM_SETTINGS, "default")

    await setDoc(
      docRef,
      {
        ...data,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    )
  }
}
