import { getOrderItemName, getOrderItemPrice, getOrderLocationLabel, getOrderTotal, getOrderTypeLabel } from "@/lib/order-utils"
import type { RestaurantOrder } from "@/types"

export function printKitchenTicket(order: RestaurantOrder) {
  printOrder(`
    <h1>Ticket cuisine</h1>
    <p><strong>Commande #${order.id.slice(-6)}</strong></p>
    <p>${getOrderTypeLabel(order.type)} - ${getOrderLocationLabel(order)}</p>
    <hr />
    ${order.items
      .map(
        (item) => `
          <div class="line">
            <strong>${item.quantity}x</strong>
            <span>${getOrderItemName(item)}</span>
          </div>
          ${item.variants?.length ? `<small>${item.variants.map((variant) => `${variant.name}: ${variant.value}`).join(", ")}</small>` : ""}
        `
      )
      .join("")}
  `)
}

export function printCustomerReceipt(order: RestaurantOrder) {
  printOrder(`
    <h1>Recu client</h1>
    <p><strong>Commande #${order.id.slice(-6)}</strong></p>
    <p>${getOrderTypeLabel(order.type)} - ${getOrderLocationLabel(order)}</p>
    <hr />
    ${order.items
      .map(
        (item) => `
          <div class="line">
            <span>${item.quantity}x ${getOrderItemName(item)}</span>
            <strong>${(getOrderItemPrice(item) * item.quantity).toLocaleString()} FCFA</strong>
          </div>
        `
      )
      .join("")}
    <hr />
    <div class="line total">
      <span>Total</span>
      <strong>${getOrderTotal(order).toLocaleString()} FCFA</strong>
    </div>
    <p>Paiement: ${order.paymentStatus}</p>
  `)
}

function printOrder(content: string) {
  const printWindow = window.open("", "_blank", "width=420,height=640")
  if (!printWindow) return

  printWindow.document.write(`
    <html>
      <head>
        <title>Impression</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 16px; color: #111; }
          h1 { font-size: 20px; margin: 0 0 12px; }
          p { margin: 6px 0; }
          hr { border: 0; border-top: 1px dashed #999; margin: 12px 0; }
          .line { display: flex; justify-content: space-between; gap: 16px; margin: 8px 0; }
          .total { font-size: 18px; }
          small { display: block; margin: -4px 0 8px 24px; color: #555; }
        </style>
      </head>
      <body>${content}</body>
    </html>
  `)
  printWindow.document.close()
  printWindow.focus()
  printWindow.print()
  printWindow.close()
}
