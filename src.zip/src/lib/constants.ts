
/**
 * @fileOverview Définition des constantes globales du système.
 */

export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  OWNER: 'owner',
  MANAGER: 'manager',
  ACCOUNTANT: 'accountant',
  CASHIER: 'cashier',
  KITCHEN: 'kitchen',
  SERVER: 'server',
} as const;

export type UserRole = typeof ROLES[keyof typeof ROLES];

export const RESTAURANT_ROLES = {
  OWNER: "owner",
  MANAGER: "manager",
  CASHIER: "cashier",
  KITCHEN: "kitchen",
} as const;

export const APP_ZONES = {
  ADMIN: "admin",
  APP: "app",
  POS: "pos",
  KITCHEN: "kitchen",
} as const;

export const POS_SESSION_STATUS = {
  OPEN: "open",
  CLOSED: "closed",
} as const;

export const SUBSCRIPTION_PLAN = {
  TRIAL: "trial",
  BASIC: "basic",
  PRO: "pro",
  CUSTOM: "custom",
  BUSINESS: "business",
} as const;

export const SUBSCRIPTION_STATUS = {
  TRIAL: "trial",
  ACTIVE: "active",
  GRACE: "grace",
  SUSPENDED: "suspended",
  LIFETIME: "lifetime",
} as const;

export const TRIAL_DAYS = 14 as const;
export const DEFAULT_GRACE_DAYS = 7 as const;
export const DEFAULT_BILLING_PERIOD_DAYS = 30 as const;

export const SUBSCRIPTION_PLAN_LABELS = {
  [SUBSCRIPTION_PLAN.TRIAL]: `Essai gratuit (${TRIAL_DAYS} jours)`,
  [SUBSCRIPTION_PLAN.BASIC]: "Basique",
  [SUBSCRIPTION_PLAN.PRO]: "Pro",
  [SUBSCRIPTION_PLAN.CUSTOM]: "Personnalisé",
  [SUBSCRIPTION_PLAN.BUSINESS]: "Business",
} as const;

export const SUBSCRIPTION_STATUS_LABELS = {
  [SUBSCRIPTION_STATUS.TRIAL]: "Essai gratuit",
  [SUBSCRIPTION_STATUS.ACTIVE]: "Actif",
  [SUBSCRIPTION_STATUS.GRACE]: "En tolérance",
  [SUBSCRIPTION_STATUS.SUSPENDED]: "Suspendu",
  [SUBSCRIPTION_STATUS.LIFETIME]: "Illimité",
} as const;

export const ORDER_STATUS = {
  PENDING: 'pending',
  ACCEPTED: "accepted",
  PREPARING: 'preparing',
  READY: 'ready',
  SERVED: 'served',
  PAID: 'paid',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled',
} as const;

export const ORDER_TYPE = {
  DINE_IN: "dine_in",
  TAKEAWAY: "takeaway",
  DELIVERY: "delivery",
  ROOM_SERVICE: "room_service",
} as const;

export const ORDER_SOURCE = {
  POS: "pos",
  QR: "qr",
  WEB: "web",
} as const;

export const PAYMENT_STATUS = {
  PENDING: "pending",
  UNPAID: 'unpaid',
  PARTIAL: 'partial',
  PAID: 'paid',
} as const;

export const SESSION_STATUS = {
  OPENED: 'opened',
  CLOSED: 'closed',
  VALIDATED: 'validated',
} as const;

export const COLLECTION_NAMES = {
  PLATFORM: 'platform',
  PLATFORM_SETTINGS: 'platformSettings',
  COMPANIES: 'companies',
  PLANS: 'plans',
  RESTAURANTS: 'restaurants',
  SUBSCRIPTIONS: 'subscriptions',
  USERS: 'users',
  STAFF: 'staff',
  REQUESTS: 'requests',
  COUNTRIES: 'countries',
  RESTAURANT_SLUGS: 'restaurantSlugs',
  USER_EMAILS: 'userEmails',
  AUDIT_LOGS: 'audit_logs',
  ERROR_LOGS: 'error_logs',
  MENUS: 'menus',
  PRODUCTS: 'products',
  ORDERS: 'orders',
  ORDER_ITEMS: 'orderItems',
  INVENTORY: 'inventory',
  CUSTOMERS: 'customers',
  TABLES: 'tables',
  ROOMS: 'rooms',
  REVIEWS: 'reviews',
  CASHIER_SESSIONS: 'cashierSessions',
  INVOICES: 'invoices',
  CONTACT_REQUESTS: 'contactRequests',
} as const;
