/**
 * @fileOverview Source de vérité unique pour les types métier.
 * Statuts en français, structure simplifiée.
 */

export type OrderStatus =
  | "nouvelle"
  | "confirmee"
  | "en_preparation"
  | "prete"
  | "servie"
  | "annulee";

export interface OrderItem {
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  table?: string;
  mode: "sur_place" | "a_emporter";
  status: OrderStatus;
  items: OrderItem[];
  total: number;
  createdAt: number; // timestamp ms
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  imageUrl?: string;
  categoryId?: string;
  available?: boolean;
}

export interface MenuCategory {
  id: string;
  name: string;
  order?: number;
}

